import React, { useState } from 'react'
import './Contact.css'
import { useForm } from 'react-hook-form';
const Contact = () => {

    const { register,
        handleSubmit,
        watch,
        setError,
        formState: { errors } }
        = useForm();

    const onSubmit = (data) => {
        alert(`Your form is submitting ${data.fname} Thank you`)
    }

    const style = {
        color: 'red'
    }

    return (
        <div>
            <main className='formSection'>
                <div className="contactForm">
                    <form action="" method="post" onSubmit={handleSubmit(onSubmit)}>
                        <h1>Contact me</h1>
                        <input type="text" {...register("fname", { pattern: { value: /^[A-Za-z]+$/i, message: "Must be entered character not a number" } })} placeholder="First name*" />
                        {errors.fname && <div className='red' style={style}> {errors.fname.message}</div>}
                        <input type="text" {...register("lname", { pattern: { value: /^[A-Za-z]+$/i, message: "Must be entered character not a number" } }, { maxLength: { value: 15, message: "Character Lenth is 15" } })} placeholder="Last name*" />
                        {errors.lname && <div className='red' style={style}>{errors.lname.message}</div>}
                        <input type="email" {...register("email", { pattern: { value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i, message: "Must be entered valid email address" } })} placeholder="Email address*" />
                        {errors.email && <div className='red' style={style}>{errors.email.message}</div>}
                        <textarea name="" {...register("textarea", { pattern: { value: /^[A-Za-z]+$/i, message: "Must be entered character not a number" } })} placeholder="Share your thoughts*"></textarea>
                        {errors.textarea && <div className='red' style={style} >{errors.textarea.message}</div>}
                        <button type="submit" className="btn">Send</button>
                    </form>
                </div>
            </main>
        </div>
    )
}

export default Contact
