import React from 'react'
import './Projects.css'
const Projects = () => {
    return (
        <div>
            <main>
                <h3>Projects</h3>
                <hr />
                <div className="projectsSection">
                    <div className="projectBox">
                        <ol>
                            <li>
                                <h4>CarWash System</h4>
                                {/* <ul>
                                        <p>Used Technology </p>
                                        <li>Java</li>
                                        <li>Spring boot</li>
                                        <li>MySQL</li>

                                    </ul> */}
                                <div className="link"><a href="">View</a><a href="">GitHub</a></div>

                            </li>
                            <li>
                                <h4>Book Management System</h4>
                                <div className="link"><a href="">View</a><a href="">GitHub</a></div>
                            </li>
                        </ol>
                    </div>
                </div>
            </main>

        </div>
    )
}

export default Projects
