import React from 'react'
import './About.css'
import Navbar from './Navbar'
import Footer from './Footer'
const About = () => {
    return (
        <div>
            <main>
                <h3>About</h3>
                <hr/>
                    <div className="aboutSection">
                        <div className="aboutLeft">
                            <h2>I have done so far.</h2>
                        </div>
                        <div className="aboutRight">
                            <p>Dedicated and adaptable professional with a proactive attitude and the ability to learn quickly.
                                Strong work ethic and
                                effective communication skills. Eager to dynamic team and support organizational goals.
                            </p>
                        </div>
                    </div>
                    <section className="skills container">
                        <div className="title">
                            <h2 className="backTitle">Skills</h2>
                        </div>
                        <div className="row">
                            <div className="item">
                                <div className="item-text">
                                    <span>Java</span>
                                    <span className="w-90">90%</span>
                                </div>
                                <div className="progress">
                                    <div className="progress-bar w-90"></div>
                                </div>
                            </div>

                            <div className="item">
                                <div className="item-text">
                                    <span>Servlet API</span>
                                    <span className="w-75">75%</span>
                                </div>
                                <div className="progress">
                                    <div className="progress-bar w-75"></div>
                                </div>
                            </div>

                            <div className="item">
                                <div className="item-text">
                                    <span>Hibernate</span>
                                    <span className="w-85">85%</span>
                                </div>
                                <div className="progress">
                                    <div className="progress-bar w-85"></div>
                                </div>
                            </div>

                            <div className="item">
                                <div className="item-text">
                                    <span>Spring boot</span>
                                    <span className="w-80">80%</span>
                                </div>
                                <div className="progress">
                                    <div className="progress-bar w-80"></div>
                                </div>
                            </div>

                            <div className="item">
                                <div className="item-text">
                                    <span>MySQL</span>
                                    <span className="w-70">70%</span>
                                </div>
                                <div className="progress">
                                    <div className="progress-bar w-70"></div>
                                </div>
                            </div>

                            <div className="item">
                                <div className="item-text">
                                    <span>HTML5</span>
                                    <span className="w-90">90%</span>
                                </div>
                                <div className="progress">
                                    <div className="progress-bar w-90"></div>
                                </div>
                            </div>

                            <div className="item">
                                <div className="item-text">
                                    <span>CSS3</span>
                                    <span className="w-80">80%</span>
                                </div>
                                <div className="progress">
                                    <div className="progress-bar w-80"></div>
                                </div>
                            </div>

                            <div className="item">
                                <div className="item-text">
                                    <span>JavaScript</span>
                                    <span className="w-80">80%</span>
                                </div>
                                <div className="progress">
                                    <div className="progress-bar w-80"></div>
                                </div>
                            </div>

                            <div className="item">
                                <div className="item-text">
                                    <span>Reactjs</span>
                                    <span className="w-70">70%</span>
                                </div>
                                <div className="progress">
                                    <div className="progress-bar w-70"></div>
                                </div>
                            </div>
                        </div>
                    </section>
            </main>
        </div>
    )
}

export default About
